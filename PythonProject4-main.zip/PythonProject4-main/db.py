import sqlite3

DATABASE = "alerts.db"

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with open("schema.sql", "r") as f:
        db = get_db()
        db.executescript(f.read())
        db.close()
        print("✅ Database initialized.")
