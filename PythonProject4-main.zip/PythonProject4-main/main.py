from db import get_db, init_db
from decision_engine import evaluate_alert


correlation_results = [
    {"event": "login", "source_ip": "192.168.1.5", "hash_match": True, "anomaly_detected": True},
    {"event": "file_access", "source_ip": "10.0.0.3", "hash_match": True, "anomaly_detected": False},
    {"event": "login", "source_ip": "172.16.0.2", "hash_match": False, "anomaly_detected": True},
    {"event": "usb", "source_ip": "192.168.1.10", "hash_match": False, "anomaly_detected": False}
]

def save_alert(event, ip, alert):
    db = get_db()
    db.execute(
        "INSERT INTO alerts (log_event, source_ip, type, description, severity) VALUES (?, ?, ?, ?, ?)",
        (event, ip, alert["type"], alert["description"], alert["severity"])
    )
    db.commit()
    db.close()

def process_correlation_results():
    for result in correlation_results:
        alert = evaluate_alert(result)
        if alert:
            print(f"🚨 [{alert['severity']}] {alert['type']} from {result['source_ip']}")
            print(f"📝 {alert['description']}\n")
            save_alert(result["event"], result["source_ip"], alert)
        else:
            print(f"✅ No alert for {result['source_ip']}\n")

if __name__ == "__main__":
    init_db()
    process_correlation_results()
